#!/usr/bin/env bash
set -euo pipefail
SDK="${ANDROID_HOME:-$HOME/Android/Sdk}"
BT="$SDK/build-tools/35.0.0"
ANDROID="$SDK/platforms/android-35/android.jar"
export JAVA_HOME="${JAVA_HOME:-/usr/lib/jvm/java-17-openjdk-amd64}"
export PATH="$JAVA_HOME/bin:$PATH"
mkdir -p build/classes build/dex
"$BT/aapt" package -f -M AndroidManifest.xml -S res -I "$ANDROID" -F build/unsigned.apk
javac -source 8 -target 8 -bootclasspath "$ANDROID" -d build/classes src/pk/cinejoy/tv/MainActivity.java
"$BT/d8" --min-api 23 --lib "$ANDROID" --output build/dex build/classes/pk/cinejoy/tv/*.class
"$BT/aapt" add build/unsigned.apk build/dex/classes.dex
# aapt preserves paths, so put classes.dex at the APK root instead.
"$BT/aapt" remove build/unsigned.apk build/dex/classes.dex
cp build/dex/classes.dex classes.dex
"$BT/aapt" add build/unsigned.apk classes.dex
rm classes.dex
"$BT/zipalign" -f 4 build/unsigned.apk build/aligned.apk
KEYSTORE="${CINEJOY_KEYSTORE:-$HOME/.android/cinejoy-debug.keystore}"
if [ ! -f "$KEYSTORE" ]; then
  mkdir -p "$(dirname "$KEYSTORE")"
  keytool -genkeypair -keystore "$KEYSTORE" -storepass android -keypass android -alias cinejoy -dname 'CN=Cinejoy local build' -keyalg RSA -keysize 2048 -validity 10000
fi
"$BT/apksigner" sign --ks "$KEYSTORE" --ks-pass pass:android --key-pass pass:android --ks-key-alias cinejoy --out Cinejoy-Android-TV.apk build/aligned.apk
"$BT/apksigner" verify Cinejoy-Android-TV.apk
